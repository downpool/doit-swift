//
//  calculatorApp.swift
//  calculator
//
//  Created by 최동현 on 2022/10/23.
//

import SwiftUI

@main
struct calculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
